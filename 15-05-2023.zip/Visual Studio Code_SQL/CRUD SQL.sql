-- ELIANA YINETH LOZANO TRIANA
-- Hemos trabajado con las siguientes palabras reservadas::::::

-- * CREATE DATABASE (para crear una nueva base de datos)

CREATE DATABASE <db>;

-- * SHOW DATABASES (para visualizar las bases de datos creadas)

SHOW DATABASES;

-- * USE (para hacer uso de una base de datos específica)

USE <db>;

-- * SHOW TABLES(para visualizar las tablas creadas en la base de datos usada)

SHOW TABLES;

-- Crearemos nuestra primera tabla, en la base de datos clasesql

 CREATE TABLE <nombre tabla>;

 CREATE TABLE aprendices(
    id INT,
    nombre_usuario VARCHAR (50),
    correo VARCHAR(50),
    edad INT,
    estado ENUM('Activo', 'Inactivo'),
    intereses TEXT,
    creado TIMESTAMP
 );

-- INT (Para tipos de datos enteros)
-- VARCHAR (Nos permite limitar la cantidad de caracteres alfanumericos de una cadena al ingresar)
-- ENUM (permite limitar las opciones de ingreso ejemplo: Si o No, Activo o Inactivo, Aprobado o Rechazado)
-- TEXT (Nos permite almacenar un mayor número de caracteres)
-- TIMESTAMP (Nos permite almacenar la fecha exácta, Año-Mes-Día-Hora-Minutos-Segundos)

-- DESC (Empleada para visualizar la estructura de la tabla creada)

DESC <aprendices>;

-- DROP TABLE (Permite eliminar una tabla creada)

DROP TABLE <n_table>;

-- Constraints (Permite aplicar reglas o restricciones a cada uno de las columnas de nuestra tabla)

 CREATE TABLE aprendices(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR (50) UNIQUE NOT NULL,
    correo VARCHAR(50) UNIQUE NOT NULL,
    edad INT UNSIGNED NOT NULL,
    estado ENUM('Activo', 'Inactivo') DEFAULT 'Inactivo',
    intereses TEXT,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 );

 -- AUTO_INCREMENT (Permite aumentar progresivamente, permitiendo que cada id sea diferente)
 -- PRIMARY KEY (Nos indica que será el identificador único para cada registro o fila de la tabla )
 -- UNIQUE (No permite valores duplicados en la columna nombre de usuario)
 -- UNSIGNED (No permite valores con signo por ejemplo negativo -18)
 -- NOT NULL (No permitira campos vacíos)
 -- DEFAULT (Nos permite declarar en valor por defecto)
 -- CURRENT_TIMESTAMP (Fecha de la creación del registro)


INSERT INTO aprendices (nombre_usuario, correo, edad, estado, intereses) 
VALUES ('Eliana', 'eylozano@sena.edu.co', 31, 'Activo', 'Con todos los poderes');

 -- INSERT INTO (Permite ingresar datos a la tabla seleccionada)
 -- SELECT * FROM (Nos permite obtener los datos ingresados en todas las columnas de la BD)
 -- VALUES (Nos permite declarar los valores a ingresar)

-- INSERT INTO (preparados para la clase) ::::::::::::
INSERT INTO aprendices (nombre_usuario, correo, edad, estado, intereses) 
VALUES ('Juan', 'juan1@hotmail.com', 17, 'Activo', 'Con todos los poderes');
INSERT INTO aprendices (nombre_usuario, correo, edad, estado, intereses) 
VALUES ('Camilo', 'camilo2@hotmail.com', 18, 'Inactivo', ' ');
INSERT INTO aprendices (nombre_usuario, correo, edad, estado, intereses) 
VALUES ('Andrea', 'Andrea3@gmail.com', 19, 'Activo', 'Nada de nada');
INSERT INTO aprendices (nombre_usuario, correo, edad, estado, intereses) 
VALUES ('Lorena', 'lorena4@gmail.com', 20, 'Activo', 'Lo importante es que hay salud');


